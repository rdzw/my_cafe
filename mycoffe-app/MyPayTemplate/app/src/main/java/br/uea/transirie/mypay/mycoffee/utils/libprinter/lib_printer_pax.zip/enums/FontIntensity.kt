package br.transire.payment_easy_library.enums.printer

enum class FontIntensity(val nivel : Int) {

    NORMAL (1),
    MEDIO (3),
    INTENSO (4)

}