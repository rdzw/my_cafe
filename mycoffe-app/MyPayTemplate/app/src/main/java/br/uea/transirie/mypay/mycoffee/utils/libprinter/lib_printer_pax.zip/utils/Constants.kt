package br.transire.payment_easy_library.utils

class Constants {

    companion object{
        const val DEBIT = 2
        const val CREDIT = 1

        const val RECEIPT_CLIENT = 1
        const val RECEIPT_ESTABLISHMENT = 0
    }
}