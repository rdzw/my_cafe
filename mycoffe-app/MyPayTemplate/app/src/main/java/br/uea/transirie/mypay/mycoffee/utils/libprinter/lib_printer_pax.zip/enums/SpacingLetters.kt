package br.transire.payment_easy_library.enums.printer

enum class SpacingLetters {



    NORMAL,
    GRANDE,
    EXTRA_GRANDE

}