package br.transire.payment_easy_library.enums.printer

enum class IndentLeft {


    TAB_ZERO,
    TAB_UM,
    TAB_DOIS,
    TAB_TRES,
    TAB_QUATRO


}