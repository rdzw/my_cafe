package br.transire.payment_easy_library.enums.printer

enum class FontSize {


    PEQUENA,
    MEDIA,
    NORMAL,
    GRANDE,
    EXTRA_GRANDE

}